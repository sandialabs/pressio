
#include "optimization_version.hpp"

namespace pressio{ namespace optimization{

inline std::string version(){
  return("optimization in PRESSIO " );
}

}}//end namespace pressio::containers
