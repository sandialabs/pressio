
#include "containers_version.hpp"

namespace pressio{ namespace containers{

inline std::string version(){
	return("containers in PRESSIO ");
}

}}//end namespace pressio::containers
