
#include "apps_burgers1d_epetra_masked.hpp"
